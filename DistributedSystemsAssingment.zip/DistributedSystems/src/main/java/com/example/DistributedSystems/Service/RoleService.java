package com.example.DistributedSystems.Service;

import org.springframework.stereotype.Service;

@Service
public class RoleService {
}
