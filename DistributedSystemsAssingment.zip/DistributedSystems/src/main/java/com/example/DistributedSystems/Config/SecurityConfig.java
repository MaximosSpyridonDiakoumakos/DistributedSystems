package com.example.DistributedSystems.Config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;

@Configuration
//@EnableWebSecurity(debug = true)
//@EnableMethodSecurity(securedEnabled = true)
public class SecurityConfig {

    //To be implemented later!
    /*@Autowired
    private AuthEntryPointJwt unauthorizedHandler;*/
}
